import React, { useState, useContext } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native';
import { AuthContext } from '../context/AuthContext';

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const { login } = useContext(AuthContext);

  const handleLogin = async () => {
	if (!email || !senha) {
	  Alert.alert('Erro', 'Por favor, preencha e-mail e senha.');
	  return;
	}
	try {
	  await login(email, senha);
	} catch (error) {
	  Alert.alert('Erro no Login', error.message);
	}
  };

  return (
	<View style={styles.container}>
	  <Text style={styles.title}>Sistema de Chamados</Text>
	  <TextInput
		style={styles.input}
		placeholder="E-mail"
		value={email}
		onChangeText={setEmail}
		keyboardType="email-address"
		autoCapitalize="none"
	  />
	  <TextInput
		style={styles.input}
		placeholder="Senha"
		value={senha}
		onChangeText={setSenha}
		secureTextEntry
	  />
	  <Button title="Entrar" onPress={handleLogin} />
	  <Button
		title="Não tenho conta, registrar"
		onPress={() => navigation.navigate('Register')}
		color="gray"
	  />
	</View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 20 },
  title: { fontSize: 24, fontWeight: 'bold', textAlign: 'center', marginBottom: 20 },
  input: {
	height: 40,
	borderColor: 'gray',
	borderWidth: 1,
	marginBottom: 12,
	padding: 10,
	borderRadius: 5,
  },
});

export default LoginScreen;