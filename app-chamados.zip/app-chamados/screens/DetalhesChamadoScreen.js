import React, { useContext, useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator, TextInput, Button, Alert } from 'react-native';
import { ChamadoContext } from '../context/ChamadoContext';
import { AuthContext } from '../context/AuthContext';

const DetalhesChamadoScreen = ({ route }) => {
  const { id_chamado } = route.params;
  const {
	chamadoSelecionado,
	isLoadingSingle,
	error,
	fetchChamadoById,
	addComentario,
	updateStatus,
	limparChamadoSelecionado,
  } = useContext(ChamadoContext);
  
  const { usuario } = useContext(AuthContext);
  const [novoComentario, setNovoComentario] = useState('');

  // --- ATUALIZAÇÃO 3 (Início) ---
  // Estado de loading local para os botões de status
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  // --- FIM DA ATUALIZAÇÃO 3 ---

  useEffect(() => {
	fetchChamadoById(id_chamado);
	return () => {
	  limparChamadoSelecionado();
	};
  }, [id_chamado]);

  const handleAddComentario = async () => {
	if (!novoComentario.trim()) return;
	try {
	  await addComentario(id_chamado, novoComentario);
	  setNovoComentario('');
	} catch (e) {
	  Alert.alert('Erro', e.message);
	}
  };

  // --- ATUALIZAÇÃO 3 (Função) ---
  const handleUpdateStatus = (novo_status) => {
	Alert.alert(
	  'Confirmar Ação',
	  `Deseja mesmo alterar o status para "${novo_status}"?`,
	  [
		{ text: 'Cancelar' },
		{ text: 'Confirmar', onPress: async () => { // Tornou a função async
			setIsUpdatingStatus(true); // Ativa o loading
			try {
			  await updateStatus(id_chamado, novo_status);
			} catch (e) {
			  Alert.alert('Erro', e.message);
			} finally {
			  setIsUpdatingStatus(false); // Desativa o loading
			}
		  } 
		},
	  ]
	);
  };
  // --- FIM DA ATUALIZAÇÃO 3 ---


  // --- ATUALIZAÇÃO 3 (Render) ---
  const renderBotoesTecnico = () => {
	if (usuario?.tipo !== 'tecnico' || !chamadoSelecionado) return null;
	const status = chamadoSelecionado.status;

	return (
	  <View style={styles.botoesTecnico}>
		{status === 'Aberto' && (
		  <Button
			title={isUpdatingStatus ? "Aguarde..." : "Assumir Chamado"}
			onPress={() => handleUpdateStatus('Em Andamento')}
			color="#ffc107"
			disabled={isUpdatingStatus} // Desabilita
		  />
		)}
		{status === 'Em Andamento' && (
		  <Button
			title={isUpdatingStatus ? "Aguarde..." : "Resolver Chamado"}
			onPress={() => handleUpdateStatus('Resolvido')}
			color="#28a745"
			disabled={isUpdatingStatus} // Desabilita
		  />
		)}
		{status === 'Resolvido' && (
		   <Button
			title={isUpdatingStatus ? "Aguarde..." : "Reabrir Chamado"}
			onPress={() => handleUpdateStatus('Em Andamento')}
			color="#dc3545"
			disabled={isUpdatingStatus} // Desabilita
		  />
		)}
	  </View>
	);
  };
  // --- FIM DA ATUALIZAÇÃO 3 ---

  // ... (render principal, if isLoadingSingle, etc. ... continua igual) ...
  if (isLoadingSingle) {
	return <ActivityIndicator size="large" style={styles.loading} />;
  }
  if (error) {
	return <Text style={styles.errorText}>{error}</Text>;
  }
  if (!chamadoSelecionado) {
	return null;
  }

  return (
	<ScrollView style={styles.container}>
	  {/* ... (Detalhes do Chamado) ... */}
	  <View style={styles.card}>
		<Text style={styles.title}>{chamadoSelecionado.titulo}</Text>
		<Text style={styles.status}>Status: {chamadoSelecionado.status}</Text>
		<Text style={styles.prioridade}>Prioridade: {chamadoSelecionado.prioridade}</Text>
		<Text style={styles.descricao}>{chamadoSelecionado.descricao}</Text>
	  </View>

	  {renderBotoesTecnico()}

	  {/* ... (Seção de Comentários) ... */}
	  <View style={styles.card}>
		<Text style={styles.sectionTitle}>Histórico de Comentários</Text>
		
		{/* ... (Render dos comentários) ... */}
		{chamadoSelecionado.comentarios.length === 0 ? (
		  <Text style={styles.comentarioTexto}>Nenhum comentário ainda.</Text>
		) : (
		  chamadoSelecionado.comentarios.map((com, index) => (
			<View key={index} style={styles.comentario}>
			  <Text style={styles.comentarioAutor}>{com.nome_usuario}</Text>
			  <Text style={styles.comentarioTexto}>{com.texto}</Text>
			  <Text style={styles.comentarioData}>
				{new Date(com.data_comentario).toLocaleString('pt-BR')}
			  </Text>
			</View>
		  ))
		)}

		{/* O input de comentário usa o 'styles.inputComentario' atualizado */}
		<TextInput
		  style={styles.inputComentario}
		  placeholder="Escreva um comentário..."
		  value={novoComentario}
		  onChangeText={setNovoComentario}
		  multiline
		/>
		<Button title="Enviar Comentário" onPress={handleAddComentario} />
	  </View>
	</ScrollView>
  );
};

const styles = StyleSheet.create({
  // ... (outros estilos continuam iguais) ...
  container: { flex: 1, backgroundColor: '#f0f0f0' },
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  errorText: { color: 'red', textAlign: 'center', marginTop: 20 },
  card: { backgroundColor: '#fff', borderRadius: 8, padding: 15, margin: 10 },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 10 },
  status: { fontSize: 16, marginBottom: 5, color: 'blue' },
  prioridade: { fontSize: 16, marginBottom: 10, color: 'orange' },
  descricao: { fontSize: 16, lineHeight: 22, color: '#333' },
  botoesTecnico: { marginHorizontal: 10, marginTop: 5, padding: 10, backgroundColor: '#fff', borderRadius: 8 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 15 },
  comentario: {
	backgroundColor: '#f9f9f9',
	borderRadius: 5,
	padding: 10,
	marginBottom: 10,
	borderWidth: 1,
	borderColor: '#eee',
  },
  comentarioAutor: { fontWeight: 'bold', color: '#0056b3' },
  comentarioTexto: { fontSize: 15 },
  comentarioData: { fontSize: 12, color: 'gray', textAlign: 'right', marginTop: 5 },

  // --- ATUALIZAÇÃO 4 (Estilo) ---
  inputComentario: {
	backgroundColor: '#f0f0f0',
	borderWidth: 1,
	borderColor: '#ddd',
	borderRadius: 5,
	padding: 10,
	minHeight: 80, // <-- AUMENTADO de 60 para 80
	marginTop: 10,
	marginBottom: 10,
	textAlignVertical: 'top',
  },
  // --- FIM DA ATUALIZAÇÃO 4 ---
});

export default DetalhesChamadoScreen;