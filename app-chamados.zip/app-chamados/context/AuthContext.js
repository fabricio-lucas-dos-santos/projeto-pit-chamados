import React, { createContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import api from '../api/axios';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [token, setToken] = useState(null);
  const [usuario, setUsuario] = useState(null);

  const login = async (email, senha) => {
	try {
	  const response = await api.post('/usuarios/login', {
		email,
		senha,
	  });

	  const { token, usuario } = response.data;
	  await AsyncStorage.setItem('token', token);
	  await AsyncStorage.setItem('usuario', JSON.stringify(usuario));
	  
	  setToken(token);
	  setUsuario(usuario);

	} catch (e) {
	  // --- ATUALIZAÇÃO AQUI ---
	  // Verifica se o erro é 401 (Não Autorizado) e retorna a mensagem amigável
	  if (e.response && e.response.status === 401) {
		throw new Error('E-mail ou senha incorretos.');
	  }
	  // Para qualquer outro erro (ex: servidor offline)
	  console.error('Erro no login:', e);
	  throw new Error('Não foi possível conectar ao servidor. Tente mais tarde.');
	  // --- FIM DA ATUALIZAÇÃO ---
	}
  };

  const registrar = async (nome, email, senha) => {
	try {
	  await api.post('/usuarios/registrar', {
		nome,
		email,
		senha,
		tipo: 'solicitante',
	  });
	} catch (e) {
	  const errorMsg = e.response?.data?.message || 'Não foi possível completar o registro.';
	  console.error('Erro no registro:', e.response?.data);
	  throw new Error(errorMsg);
	}
  };

  // ... (restante do arquivo: logout, estaLogado, useEffect, etc. ... continua igual) ...

  const logout = async () => {
	setIsLoading(true);
	await AsyncStorage.removeItem('token');
	await AsyncStorage.removeItem('usuario');
	setToken(null);
	setUsuario(null);
	setIsLoading(false);
  };

  const estaLogado = async () => {
	try {
	  const tokenSalvo = await AsyncStorage.getItem('token');
	  const usuarioSalvo = await AsyncStorage.getItem('usuario');

	  if (tokenSalvo && usuarioSalvo) {
		setToken(tokenSalvo);
		setUsuario(JSON.parse(usuarioSalvo));
	  }
	} catch (e) {
	  console.error("Erro ao checar login:", e);
	} finally {
	  setIsLoading(false);
	}
  };

  useEffect(() => {
	estaLogado();
  }, []);

  return (
	<AuthContext.Provider
	  value={{
		isLoading,
		token,
		usuario,
		login,
		logout,
		registrar,
	  }}>
	  {children}
	</AuthContext.Provider>
  );
};