import React, { useContext } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { AuthContext } from '../context/AuthContext';

import HomeScreen from '../screens/HomeScreen';
import LoginScreen from '../screens/LoginScreen';
import RegisterScreen from '../screens/RegisterScreen';
import LoadingScreen from '../screens/LoadingScreen';
import NovoChamadoScreen from '../screens/NovoChamadoScreen';
import DetalhesChamadoScreen from '../screens/DetalhesChamadoScreen';

const Stack = createNativeStackNavigator();

const AuthStack = () => (
  <Stack.Navigator screenOptions={{ headerShown: false }}>
	<Stack.Screen name="Login" component={LoginScreen} />
	<Stack.Screen name="Register" component={RegisterScreen} />
  </Stack.Navigator>
);

const AppStack = () => (
  <Stack.Navigator>
	<Stack.Screen 
	  name="Home" 
	  component={HomeScreen} 
	  options={{ title: 'Meus Chamados' }} 
	/>
	<Stack.Screen
	  name="NovoChamado"
	  component={NovoChamadoScreen}
	  options={{ title: 'Abrir Novo Chamado' }}
	/>
	<Stack.Screen
	  name="DetalhesChamado"
	  component={DetalhesChamadoScreen}
	  options={{ title: 'Detalhes do Chamado' }}
	/>
  </Stack.Navigator>
);

const AppNavigator = () => {
  const { isLoading, token } = useContext(AuthContext);

  if (isLoading) {
	return <LoadingScreen />;
  }

  return (
	<NavigationContainer>
	  {token === null ? <AuthStack /> : <AppStack />}
	</NavigationContainer>
  );
};

export default AppNavigator;